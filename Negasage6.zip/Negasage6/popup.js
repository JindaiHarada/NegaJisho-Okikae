////dictionary////

let level = 0;
let similarity = 0;

//ストレージに記録されている直近の数値設定を表示
chrome.storage.local.get(['key'], function (words) {
    document.querySelector('h1').textContent = ("dictionary"+words.key);}
  );


document.getElementById('btn_0.06').addEventListener('click', () => {
    document.querySelector('h1').textContent = "dictionary0.06";
    
    level = 0.06;
    //ローカルストレージにセット
    chrome.storage.local.set({'key': level}, function () {
    });

})


document.getElementById('btn_0.07').addEventListener('click', () => {
    document.querySelector('h1').textContent = "dictionary0.07";

    level = 0.07;
    //ローカルストレージにセット
    chrome.storage.local.set({'key': level}, function () {
    });

})


document.getElementById('btn_0.08').addEventListener('click', () => {
    document.querySelector('h1').textContent = "dictionary0.08";

    level = 0.08;
    //ローカルストレージにセット
    chrome.storage.local.set({'key': level}, function () {
    });

})



////similarity////


//ストレージに記録されている直近の数値設定を表示
chrome.storage.local.get(['simikey'], function (ruigi) {
    document.querySelector('h2').textContent = ("similarity"+ruigi.simikey);}
  );



  //btn_resetがクリックされたら
document.getElementById('btn_reset').addEventListener('click', () => {

    //ローカルストレージにセット(-1)
    chrome.storage.local.set({'simikey': (0)}, function () {
    });

    //similarity-1を表示
    document.querySelector('h2').textContent = ("similarity"+(0));

})



//btn_-1がクリックされたら
document.getElementById('btn_-1').addEventListener('click', () => {
    
    chrome.storage.local.get(['simikey'], function (similarity) {
        //alert(similarity.simikey-1);

        //ローカルストレージにセット
        chrome.storage.local.set({'simikey': (similarity.simikey-1)}, function () {
        });

        
        document.querySelector('h2').textContent = ("similarity"+(similarity.simikey-1));
    });


})



//btn_+1がクリックされたら
document.getElementById('btn_+1').addEventListener('click', () => {
    
    chrome.storage.local.get(['simikey'], function (similarity) {
        //alert(similarity.simikey+1);

        //ローカルストレージにセット
        chrome.storage.local.set({'simikey': (similarity.simikey+1)}, function () {
        });

        document.querySelector('h2').textContent = ("similarity"+(similarity.simikey+1));
    });


})



////ON OFF////
//ストレージに記録されている直近のON/OFFを表示
chrome.storage.local.get(['swkey'], function (onoroff) {
    if(onoroff.swkey == 1){
        document.querySelector('h3').textContent = "switch ON";
    }
    else if(onoroff.swkey == 0){
        document.querySelector('h3').textContent = "switch OFF";
    }

    });

document.getElementById('btn_off').addEventListener('click', () => {
    document.querySelector('h3').textContent = "switch OFF";

    sw = 0;
    //ローカルストレージにセット
    chrome.storage.local.set({'swkey': sw}, function () {
    });

})

document.getElementById('btn_on').addEventListener('click', () => {
    document.querySelector('h3').textContent = "switch ON";

    sw = 1;
    //ローカルストレージにセット
    chrome.storage.local.set({'swkey': sw}, function () {
    });

})